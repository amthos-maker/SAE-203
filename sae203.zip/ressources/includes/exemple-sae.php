<head>
    <link rel="stylesheet" href="./ressources/css/sae-exemple.css">
</head>

<section class="articles">
        <!-- LIGNEE : PREMIERE -->
    <div class="premiere-ligne">
        <div class="littlebox">
            <div class="article-box">
                <div class="article-image">
                    <img src="./ressources/images/image-article.png" alt="Article">
                </div>
                <div class="article-text">
                    <h2 class="titre-sae">Auditer une communication numérique • SAÉ101</h2>
                        <p  class="dev-web-txt">
                        Apprendre les bases du reportage vidéo sur un suejt libre
                    </p>
                </div>
            </div>
        </div>
        <div class="littlebox">
            <div class="article-box">
                <div class="article-image">
                    <img src="ressources/images/image-article.png" alt="Article">
                </div>
                <div class="article-text">
                    <h2 class="titre-sae">Concevoir une recommandation de communication numérique • SAÉ102</h2>
                    <p class="dev-web-txt">
                        Apprendre les bases du reportage vidéo sur un sujet libre
                    </p>
                </div>
            </div>
        </div>
        <div class="littlebox">
            <div class="article-box">
                <div class="article-image">
                    <img src="ressources/images/image-article.png" alt="Article">
                </div>
                <div class="article-text">
                    <h2 class="titre-sae">Produire les éléments d'une communication visuelle • SAÉ103</h2>
                    <p  class="dev-web-txt">
                        Apprendre les bases du reportage sur un sujet libre
                    </p>
                </div>
            </div>
        </div>
</div>
        <!-- LIGNEE : DEUXIEME -->
    <div class="deuxieme-ligne">
        <div class="littlebox">
            <div class="article-box">
                <div class="article-image">
                    <img src="ressources/images/image-article.png" alt="Article">
                </div>
                <div class="article-text">
                    <h2 class="titre-sae">Produire un contenu audio et vidéo • SAÉ104</h2>
                        <p  class="dev-web-txt">
                        Apprendre les bases du reportage vidéo sur un sujet libre
                    </p>
                </div>
            </div>
        </div>
        <div class="littlebox">
            <div class="article-box">
                <div class="article-image">
                    <img src="ressources/images/image-article.png" alt="Article">
                </div>
                <div class="article-text">
                    <h2 class="titre-sae">Produire un site WEB • SAÉ105</h2>
                    <p class="dev-web-txt">
                        Apprendre les bases du reportage vidéo sur un sujet libre
                    </p>
                </div>
            </div>
        </div>
        <div class="littlebox">
            <div class="article-box">
                <div class="article-image">
                    <img src="ressources/images/image-article.png" alt="Article">
                </div>
                <div class="article-text">
                    <h2 class="titre-sae">Gérer un projet de communication numérique • SAÉ106</h2>
                    <p>
                        Apprendre les bases du reportage vidéo sur un sujet libre
                    </p>
                </div>
            </div>
        </div>
    </div>